import React from 'react';
import { render } from '@testing-library/react';
import NavigationBar from './NavigationBar';

test('renders navigation bar', () => {
  render(<NavigationBar />);
  // Add specific assertions here
});
