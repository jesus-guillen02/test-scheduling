import React from 'react';
import { render } from '@testing-library/react';
import AboutSection from './AboutSection';

test('renders about section', () => {
  render(<AboutSection />);
  // Add specific assertions here
});
